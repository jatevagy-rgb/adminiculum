/**
 * Settings Routes V2
 * API endpoints for application settings
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=routes.d.ts.map