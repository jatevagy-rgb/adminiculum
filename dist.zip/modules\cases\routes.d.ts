/**
 * Cases Routes Module V3
 * Case management endpoints with Timeline + Documents integration
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=routes.d.ts.map