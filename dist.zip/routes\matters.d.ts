declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=matters.d.ts.map