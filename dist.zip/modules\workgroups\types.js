"use strict";
/**
 * Workgroup Module Types
 * Client workload tracking module
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=types.js.map