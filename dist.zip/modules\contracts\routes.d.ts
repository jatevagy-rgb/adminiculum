/**
 * Contracts Routes
 * API endpoints for contract template management and document generation
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=routes.d.ts.map