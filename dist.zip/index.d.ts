/**
 * Adminiculum Backend V2 - Main Application Entry Point
 * Legal Document Management System API
 * Modular Architecture
 */
declare const app: import("express-serve-static-core").Express;
export default app;
//# sourceMappingURL=index.d.ts.map