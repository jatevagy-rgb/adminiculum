/**
 * Users Routes Module V2
 * User management endpoints
 * Matching Frontend Data Contract
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=routes.d.ts.map