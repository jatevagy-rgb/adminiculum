export declare const jwtConfig: {
    secret: string;
    refreshSecret: string;
    expiresIn: string;
    refreshExpiresIn: string;
};
//# sourceMappingURL=jwt.d.ts.map