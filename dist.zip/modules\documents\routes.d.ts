/**
 * Documents Routes V2
 * Document management with SharePoint integration
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=routes.d.ts.map