/**
 * Workgroup Routes
 * Client workload tracking API endpoints
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=routes.d.ts.map