/**
 * Settings Module Index
 * V2 Modular Structure
 */

export { default as settingsService } from './settings';
export { default as settingsRoutes } from './routes';
